package com.accenture.amr;

public class Hello_Ammar2 {
    public static void main(String[] args) {

            System.out.println("Hello Ammar!");

    }
}
