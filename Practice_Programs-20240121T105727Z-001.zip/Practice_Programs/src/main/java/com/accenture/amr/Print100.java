package com.accenture.amr;

public class Print100 {
//    private static int a;

    public static void main(String[] args) {

//        for(int a =1;a<=100;a++);
//        {
//            System.out.println(a);
//        }

        for (int a = 0; a <= 100; a++) {
            System.out.println(a);
        }
    }
}