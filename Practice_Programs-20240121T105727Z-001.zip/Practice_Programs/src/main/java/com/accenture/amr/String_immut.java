package com.accenture.amr;

public class String_immut {
    public static void main(String[] args) {
        int i= 5;
        i=10;
        String str = "amr";
        str = "abu";
        System.out.println(i);
        System.out.println(str);
    }
}
