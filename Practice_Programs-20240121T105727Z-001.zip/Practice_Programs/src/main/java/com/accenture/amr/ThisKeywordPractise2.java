package com.accenture.amr;

public class ThisKeywordPractise2 {
    int u;

    public   ThisKeywordPractise2()
    {
        this.u = u;
    }

    public static void main(String[] args) {
        System.out.println("practise 2 value is" );
    }
}
