package com.accenture.amr;

public class GetSetCall2 {
    public static void main(String[] args) {
        GetSet call2 = new GetSet();

        call2.setName("SS Ammar");
        System.out.println(call2.getName());
    }
}
