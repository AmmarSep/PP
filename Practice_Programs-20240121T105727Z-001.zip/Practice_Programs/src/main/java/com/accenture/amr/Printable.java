package com.accenture.amr;

public interface Printable {
    void print();
}
