/*
package com.accenture.amr;

import java.util.ArrayList;
import java.util.List;

public class ESError {
    public static List<Object> validateSaveAgentCompensationRequest(List<Object> products)
    {
        List<Object> errorList = new ArrayList<>();
        for(Object object : products){
            if(org.apache.commons.lang3.StringUtils.isBlank(object.getProductCd())){
                errorList.add(EISError.builder().errorCode(EISServiceConstant.VALIDATION_CODE)
                        .message(EISServiceConstant.VALIDATION_TEXT)
                        .field(EISServiceConstant.FIELD_PRODUCT_CD)
                        .build());
            }
            if
        }
        return errorList;
    }

}
*/
