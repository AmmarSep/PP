package com.accenture.amr;

public class SimpleOperator {

    public static void main(String[] args) {
	// write your code here
        int num1=4 , num2=2, sum, product, difference ;
        sum = num1+num2;
        product =  num1*num2;
        difference=num1-num2;
        System.out.println("Addition of two numbers: "+sum);
        System.out.println("Product of two numbers: " +product);
        System.out.println("Difference of two numbers: "+difference);
    }
}
