package com.accenture.amr;

public class Cat implements  Printable{
    public String name;
    public int Age;
    public Cat(){}
    public void print(){
        System.out.println("Meowzzxx");
    }

}
